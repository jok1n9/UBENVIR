UA/DETI � An�lise de Sistemas 
Joaquim Andrade (93432), Francisco Silva(93400), Arthur Monetto(102667) 


Deployment: UBENVIR

Plataformas utilizadas:
Github(p�blico): jok1n9/UBENVIR: Company prototype for System Analisys https://github.com/jok1n9/UBENVIR
Herokuapp(github deployed): P�gina Inicial (ubenvir.herokuapp.com)


Existem dois logins e registos diferentes dependendo se s�o uma empresa ou um particular.
O registo particular � intuitivo e requer apenas que o n�mero de telem�vel e o nif sejam num�ricos.
Para login j� existe uma conta criada na base de dados com os seguintes dados:
User: joking
Pass : joking123

Para registar uma empresa � preciso introduzir os dados sendo o n�mero de telem�vel e o numero de conta bancaria num�ricos. Ap�s o registo � necess�rio aceder � p�gina do admin para aceitar o registo.
Para dar login j� existe a seguinte conta:
User:continente
Pass: continente123

Caso acedam ao login pela empresa, podem, ou entrar na p�gina de administrador preenchendo o user com �admin@� e deixando a pass em branco.


Para adicionar produtos, basta preencher as informa��es dentro do question�rio. E clicar em �add product�. N�o existe rea��o h� adic�o de produtos, mas se tocar em back to homepage eles s�o adicionados.
 



